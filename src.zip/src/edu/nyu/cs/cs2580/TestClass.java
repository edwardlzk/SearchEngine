package edu.nyu.cs.cs2580;

import java.io.IOException;

public class TestClass {

	public TestClass() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		IndexerInvertedOccurrence invOcc = new IndexerInvertedOccurrence();
		invOcc.constructIndex();
	}

}
